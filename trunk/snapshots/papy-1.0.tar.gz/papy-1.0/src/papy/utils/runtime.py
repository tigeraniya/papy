"""
:mod:`papy.utils.runtime`
=========================
Provides a (possibly shared) dictionary.
"""
def get_runtime():
    PAPY_RUNTIME = {}
    return PAPY_RUNTIME
