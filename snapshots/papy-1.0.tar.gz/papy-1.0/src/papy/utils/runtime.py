"""
:mod:`papy.utils.runtime`
=========================

Provides a (possibly shared, but not yet) dictionary.
"""
def get_runtime():
    PAPY_RUNTIME = {}
    return PAPY_RUNTIME



# EOF
