from papy import *
from IMap import IMap


def power(i):
    #print multiprocessing.current_process(),
    #print i
    return i[0] * i[0]
def sum2(i):
    return i[0] + i[1]


def pipeline():
    imap1 = IMap(worker_type="process", worker_num=2, stride=2, buffer=None, ordered =True, skip =False, name ="imap1")
    imap_54203472 = IMap(worker_type="process", worker_num=2, stride=2, buffer=None, ordered =True, skip =False, name ="imap_54203472")
    imap2 = IMap(worker_type="process", worker_num=2, stride=2, buffer=None, ordered =True, skip =False, name ="imap2")


    power_p1 = Piper(Worker((power,), ((),), ({},)), parallel=imap1, consume=1, produce=1, spawn=1, timeout=None, branch=None, debug=True, name="power_p1", track=True)
    power_p2 = Piper(Worker((power,), ((),), ({},)), parallel=imap_54203472, consume=1, produce=1, spawn=1, timeout=None, branch=None, debug=True, name="power_p2", track=True)
    power_p3 = Piper(Worker((power,), ((),), ({},)), parallel=imap2, consume=1, produce=1, spawn=1, timeout=None, branch=None, debug=True, name="power_p3", track=True)
    sum_p4 = Piper(Worker((sum2,), ((),), ({},)), parallel=imap2, consume=1, produce=1, spawn=1, timeout=None, branch=None, debug=True, name="sum_p4", track=True)


    pipers = [power_p1, power_p2, power_p3, sum_p4]
    xtras = [[{'name': 'power_p1'}, {'name': 'power_p2'}, {'name': 'power_p3'}, {'name': 'sum_p4'}],[{'name': 'power_p1'}, {'name': 'power_p2'}, {'name': 'power_p3'}, {'name': 'sum_p4'}],[{'name': 'power_p1'}, {'name': 'power_p2'}, {'name': 'power_p3'}, {'name': 'sum_p4'}],[{'name': 'power_p1'}, {'name': 'power_p2'}, {'name': 'power_p3'}, {'name': 'sum_p4'}]]
    pipes  = [(power_p2, sum_p4), (power_p2, power_p3), (power_p1, power_p2), (power_p3, sum_p4)]
    return (pipers, xtras, pipes)

if __name__ == "__main__":
    pipeline()

