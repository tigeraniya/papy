"""
:mod:`papy.tkgui`
===================
Tkinter/Pmw gui for PaPy. Provides also a Tkinter shell widget.

"""

#EOF
